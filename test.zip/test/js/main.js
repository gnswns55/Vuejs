import {
    conHello,
    fnPlusNumbers
 } from './js/library_named';
console.log(conHello, '이름으로 내보내기입니다.');
console.log('1+2 = ', fnPlusNumbers(1,2));

//named export 라이브러리 모듈을 가져와서 mylibrary 객체에 모두 저장
import * as myLibrary from './js/library_named';
console.log(myLibrary.conHello, '*을 사용한 이름으로 내보내기입니다.');
console.log('3+4 = ', myLibrary.fnPlusNumbers(3,4));

//defult export 모듈 사용
import fnMyfunction from './js/library_default.js';
console.log('안녕하세요! 기본으로 내보내기입니다.')
console.log('5+6 =', fnMyfunction(5,6));